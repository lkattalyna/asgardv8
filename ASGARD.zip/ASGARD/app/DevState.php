<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DevState extends Model
{
    protected $guarded = [];
}
