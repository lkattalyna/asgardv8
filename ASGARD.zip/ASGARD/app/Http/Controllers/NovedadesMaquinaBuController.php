<?php

namespace App\Http\Controllers;

use App\Models\NovedadesMaquinaBu;
use Illuminate\Http\Request;

class NovedadesMaquinaBuController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\NovedadesMaquinaBu  $novedadesMaquinaBu
     * @return \Illuminate\Http\Response
     */
    public function show(NovedadesMaquinaBu $novedadesMaquinaBu)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\NovedadesMaquinaBu  $novedadesMaquinaBu
     * @return \Illuminate\Http\Response
     */
    public function edit(NovedadesMaquinaBu $novedadesMaquinaBu)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\NovedadesMaquinaBu  $novedadesMaquinaBu
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, NovedadesMaquinaBu $novedadesMaquinaBu)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\NovedadesMaquinaBu  $novedadesMaquinaBu
     * @return \Illuminate\Http\Response
     */
    public function destroy(NovedadesMaquinaBu $novedadesMaquinaBu)
    {
        //
    }
}
