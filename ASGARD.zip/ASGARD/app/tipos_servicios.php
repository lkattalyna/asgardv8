<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tipos_servicios extends Model
{
    //
    protected $fillable = ['nombre'];
}
