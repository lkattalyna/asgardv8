<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tipos_racks extends Model
{
    //
    protected $fillable = ['nombre'];
}
