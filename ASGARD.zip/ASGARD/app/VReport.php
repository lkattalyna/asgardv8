<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VReport extends Model
{
    //
}
