<?php

namespace App;

use Illuminate\Database\Eloquent\Model;



class tipos_hardware extends Model
{
    //
    protected $table='tipos_hardwares';
    protected $fillable = ['nombre'];

}
