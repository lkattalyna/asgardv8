<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class data_centers extends Model
{
    //
    protected $fillable = ['nombre','ubicacion'];
}
