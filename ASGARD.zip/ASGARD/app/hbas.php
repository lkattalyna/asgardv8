<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class hbas extends Model
{
    //
    protected $guarded = [];
}
