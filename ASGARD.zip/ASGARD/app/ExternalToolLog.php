<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExternalToolLog extends Model
{
    protected $guarded = [];
}
