<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class propietarios extends Model
{
    //
    protected $fillable = ['nombre'];
}
