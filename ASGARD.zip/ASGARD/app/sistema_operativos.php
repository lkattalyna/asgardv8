<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class sistema_operativos extends Model
{
    //
    protected $fillable = ['nombre'];
}
