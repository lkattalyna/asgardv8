<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class controladoras extends Model
{
    //
    protected $fillable = ['nombre'];
}
