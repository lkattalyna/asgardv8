<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VirtualHost extends Model
{
    protected $guarded = [];
}
