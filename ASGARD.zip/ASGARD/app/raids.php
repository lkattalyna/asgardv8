<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class raids extends Model
{
    //
    protected $fillable = ['tipo'];
}
