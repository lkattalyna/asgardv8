param()

begin{
}
Process{
     Set-Location -path 'C:\inetpub\wwwroot\_proceso_generador_informes'
	$salida = py .\main.py LISTAR
}
end{
    return $salida
}