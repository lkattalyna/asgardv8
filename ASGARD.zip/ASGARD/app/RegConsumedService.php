<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RegConsumedService extends Model
{
    protected $fillable = ['name'];
}
