<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SiteLog extends Model
{
    //
}
