<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CloudApiAccount extends Model
{
    protected $guarded = [];
}
