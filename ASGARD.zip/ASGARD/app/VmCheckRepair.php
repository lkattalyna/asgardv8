<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VmCheckRepair extends Model
{
    //
}
