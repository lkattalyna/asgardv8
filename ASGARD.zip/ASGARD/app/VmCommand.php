<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VmCommand extends Model
{
    protected $guarded = [];
}
