<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DevTask extends Model
{
    protected $guarded = [];
}
