<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\data_centers;
use Faker\Generator as Faker;

$factory->define(data_centers::class, function (Faker $faker) {
    return [
        //
    ];
});
