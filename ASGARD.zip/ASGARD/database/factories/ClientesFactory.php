<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\clientes;
use Faker\Generator as Faker;

$factory->define(clientes::class, function (Faker $faker) {
    return [
        //
    ];
});
