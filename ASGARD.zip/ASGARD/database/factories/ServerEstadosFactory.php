<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\server_estados;
use Faker\Generator as Faker;

$factory->define(server_estados::class, function (Faker $faker) {
    return [
        //
    ];
});
