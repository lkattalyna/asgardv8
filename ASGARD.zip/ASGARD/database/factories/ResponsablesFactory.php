<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\responsables;
use Faker\Generator as Faker;

$factory->define(responsables::class, function (Faker $faker) {
    return [
        //
    ];
});
