<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\tipos_clientes;
use Faker\Generator as Faker;

$factory->define(tipos_clientes::class, function (Faker $faker) {
    return [
        //
    ];
});
