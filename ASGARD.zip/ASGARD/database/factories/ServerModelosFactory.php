<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\server_modelos;
use Faker\Generator as Faker;

$factory->define(server_modelos::class, function (Faker $faker) {
    return [
        //
    ];
});
