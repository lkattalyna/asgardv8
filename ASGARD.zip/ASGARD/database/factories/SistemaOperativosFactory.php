<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\sistema_operativos;
use Faker\Generator as Faker;

$factory->define(sistema_operativos::class, function (Faker $faker) {
    return [
        //
    ];
});
