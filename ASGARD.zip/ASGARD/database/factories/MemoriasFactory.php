<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\memorias;
use Faker\Generator as Faker;

$factory->define(memorias::class, function (Faker $faker) {
    return [
        //
    ];
});
