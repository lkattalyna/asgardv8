<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\cpu_marcas;
use Faker\Generator as Faker;

$factory->define(cpu_marcas::class, function (Faker $faker) {
    return [
        //
    ];
});
