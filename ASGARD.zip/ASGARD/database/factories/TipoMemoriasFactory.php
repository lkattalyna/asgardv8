<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\tipo_memorias;
use Faker\Generator as Faker;

$factory->define(tipo_memorias::class, function (Faker $faker) {
    return [
        //
    ];
});
