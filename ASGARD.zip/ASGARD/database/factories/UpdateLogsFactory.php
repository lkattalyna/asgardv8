<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\update_logs;
use Faker\Generator as Faker;

$factory->define(update_logs::class, function (Faker $faker) {
    return [
        //
    ];
});
