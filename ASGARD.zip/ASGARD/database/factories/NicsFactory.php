<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\nics;
use Faker\Generator as Faker;

$factory->define(nics::class, function (Faker $faker) {
    return [
        //
    ];
});
