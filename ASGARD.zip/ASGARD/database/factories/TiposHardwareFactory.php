<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\tipos_hardware;
use Faker\Generator as Faker;

$factory->define(tipos_hardware::class, function (Faker $faker) {
    return [
        //
    ];
});
