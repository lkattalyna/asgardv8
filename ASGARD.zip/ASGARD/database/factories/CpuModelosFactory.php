<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\cpu_modelos;
use Faker\Generator as Faker;

$factory->define(cpu_modelos::class, function (Faker $faker) {
    return [
        //
    ];
});
