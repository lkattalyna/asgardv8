<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\nic_referencias;
use Faker\Generator as Faker;

$factory->define(nic_referencias::class, function (Faker $faker) {
    return [
        //
    ];
});
