<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\cpus;
use Faker\Generator as Faker;

$factory->define(cpus::class, function (Faker $faker) {
    return [
        //
    ];
});
