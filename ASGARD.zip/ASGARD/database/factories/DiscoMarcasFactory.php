<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\disco_marcas;
use Faker\Generator as Faker;

$factory->define(disco_marcas::class, function (Faker $faker) {
    return [
        //
    ];
});
