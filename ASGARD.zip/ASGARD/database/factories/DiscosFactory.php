<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\discos;
use Faker\Generator as Faker;

$factory->define(discos::class, function (Faker $faker) {
    return [
        //
    ];
});
