<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\server_marcas;
use Faker\Generator as Faker;

$factory->define(server_marcas::class, function (Faker $faker) {
    return [
        //
    ];
});
