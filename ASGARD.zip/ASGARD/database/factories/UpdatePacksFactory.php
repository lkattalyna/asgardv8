<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\update_packs;
use Faker\Generator as Faker;

$factory->define(update_packs::class, function (Faker $faker) {
    return [
        //
    ];
});
