<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\propietarios;
use Faker\Generator as Faker;

$factory->define(propietarios::class, function (Faker $faker) {
    return [
        //
    ];
});
