<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\servers;
use Faker\Generator as Faker;

$factory->define(servers::class, function (Faker $faker) {
    return [
        //
    ];
});
