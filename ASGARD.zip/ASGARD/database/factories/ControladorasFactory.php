<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\controladoras;
use Faker\Generator as Faker;

$factory->define(controladoras::class, function (Faker $faker) {
    return [
        //
    ];
});
