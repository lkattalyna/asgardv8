<?php

use Illuminate\Database\Seeder;

class UpdateLogsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
