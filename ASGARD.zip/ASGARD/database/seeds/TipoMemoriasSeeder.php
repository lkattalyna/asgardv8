<?php

use Illuminate\Database\Seeder;

class TipoMemoriasSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
